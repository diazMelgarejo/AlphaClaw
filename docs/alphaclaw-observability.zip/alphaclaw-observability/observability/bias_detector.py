from difflib import SequenceMatcher
from dataclasses import dataclass
from typing import List, Dict

@dataclass
class BiasScore:
    total_bias_score: float
    bias_types: Dict[str, float]
    agreement_collapse: bool
    echo_loop_detected: bool

class AlphaClawBiasDetector:
    def __init__(self):
        self.history = []

    def add_decision(self, confidence: float, reasoning_text: str, agent_outputs: List[str]):
        self.history.append({"confidence": confidence, "text": reasoning_text[:500]})
        if len(self.history) > 20:
            self.history.pop(0)

    def detect_bias(self) -> BiasScore:
        if len(self.history) < 4:
            return BiasScore(0.0, {}, False, False)

        confidences = [d["confidence"] for d in self.history]
        texts = [d["text"] for d in self.history]

        collapse_score = 1.0 - (sum(abs(confidences[i] - confidences[i-1]) for i in range(1, len(confidences))) / (len(confidences)-1))
        agreement_collapse = collapse_score > 0.85

        echo_loop = any(SequenceMatcher(None, texts[i], texts[i-1]).ratio() > 0.92 for i in range(1, len(texts)))

        bias_types = {
            "confirmation_bias": max(0.0, (sum(confidences)/len(confidences) - 0.5) * 2),
            "groupthink": collapse_score,
            "hallucination_risk": max(0.0, 1.0 - sum(confidences)/len(confidences))
        }

        total_bias = min(1.0, sum(bias_types.values()) / 2)

        return BiasScore(round(total_bias, 3), {k: round(v, 3) for k, v in bias_types.items()}, agreement_collapse, echo_loop)
