from opentelemetry import trace, metrics
from opentelemetry.trace import SpanKind
from opentelemetry.sdk.trace import TracerProvider
from opentelemetry.sdk.resources import Resource
from opentelemetry.sdk.trace.export import BatchSpanProcessor
from opentelemetry.exporter.otlp.proto.http.trace_exporter import OTLPSpanExporter
from opentelemetry.exporter.otlp.proto.http.metric_exporter import OTLPMetricExporter
from opentelemetry.sdk.metrics import MeterProvider
from opentelemetry.sdk.metrics.export import PeriodicExportingMetricReader
import uuid
import time
from difflib import SequenceMatcher

tracer_provider = TracerProvider(resource=Resource.create({"service.name": "alphaclaw"}))
trace.set_tracer_provider(tracer_provider)
tracer = trace.get_tracer("alphaclaw.agent")

# Metrics
meter_provider = MeterProvider()
metrics.set_meter_provider(meter_provider)
meter = metrics.get_meter("alphaclaw.metrics")

task_counter = meter.create_counter("task_total")
hallucination_counter = meter.create_counter("hallucination_events_total")
bias_counter = meter.create_counter("bias_events_total")
failure_counter = meter.create_counter("failure_events_total", unit="1", description="Failures by type")

# Exporters
span_exporter = OTLPSpanExporter(endpoint="http://localhost:4318/v1/traces")
metric_exporter = OTLPMetricExporter(endpoint="http://localhost:4318/v1/metrics")

tracer_provider.add_span_processor(BatchSpanProcessor(span_exporter))
meter_provider.add_reader(PeriodicExportingMetricReader(metric_exporter))

class AlphaClawSpanEmitter:
    def __init__(self):
        self.current_task_id = None

    def start_task(self, task_type: str):
        self.current_task_id = str(uuid.uuid4())
        task_counter.add(1)
        return tracer.start_as_current_span(
            "orchestrator.run",
            kind=SpanKind.SERVER,
            attributes={"task.id": self.current_task_id, "task.type": task_type}
        )

    def emit_agent_span(self, role: str, attributes: dict = None):
        if attributes is None:
            attributes = {}
        attributes.update({
            "agent.role": role,
            "task.id": self.current_task_id,
        })
        return tracer.start_as_current_span(f"agent.{role}.run", kind=SpanKind.INTERNAL, attributes=attributes)

    def record_decision(self, confidence: float, consensus: float, disagreement: float):
        span = trace.get_current_span()
        span.set_attributes({
            "decision.confidence": confidence,
            "decision.consensus_score": consensus,
            "decision.disagreement_score": disagreement
        })

    def record_failure(self, failure_type: str, details: str = ""):
        span = trace.get_current_span()
        span.set_attributes({"failure.type": failure_type, "failure.details": details})
        failure_counter.add(1, {"failure.type": failure_type})

    def record_bias(self, bias_type: str, score: float):
        span = trace.get_current_span()
        span.set_attributes({"bias.detected": True, "bias.type": bias_type})
        bias_counter.add(1, {"bias.type": bias_type})

emitter = AlphaClawSpanEmitter()
