# AlphaClaw Observability Stack v0.9.9.6

Production-ready cognitive observability system.

Full OTel (OpenTelemetry) + Prometheus observability for AlphaClaw (Mac + Windows hybrid).

## Quick Start
1. ```bash
docker compose up -d
```
2. Replace your current `openclaw.json` with the one in this repo
3. Restart AlphaClaw
4. Open Grafana at http://localhost:3000

Everything is production-ready: traces, logs, metrics, bias detection, and hallucinations.
